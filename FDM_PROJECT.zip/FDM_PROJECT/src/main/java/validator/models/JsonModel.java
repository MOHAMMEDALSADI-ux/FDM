package validator.models;

public class JsonModel {

	int id;
	int type_id;
	String tag_name;
	int order;
	Boolean is_conditional_tag;

	public JsonModel() {
		super();
	}

	public JsonModel(int id, int type_id, String tag_name, int order, Boolean is_conditional_tag) {
		super();
		this.id = id;
		this.type_id = type_id;
		this.tag_name = tag_name;
		this.order = order;
		this.is_conditional_tag = is_conditional_tag;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getType_id() {
		return type_id;
	}

	public void setType_id(int type_id) {
		this.type_id = type_id;
	}

	public String getTag_name() {
		return tag_name;
	}

	public void setTag_name(String tag_name) {
		this.tag_name = tag_name;
	}

	public int getOrder() {
		return order;
	}

	public void setOrder(int order) {
		this.order = order;
	}

	public Boolean getIs_conditional_tag() {
		return is_conditional_tag;
	}

	public void setIs_conditional_tag(Boolean is_conditional_tag) {
		this.is_conditional_tag = is_conditional_tag;
	}

	@Override
	public String toString() {
		return "JsonModel [id=" + id + ", type_id=" + type_id + ", tag_name=" + tag_name + ", order=" + order
				+ ", is_conditional_tag=" + is_conditional_tag + "]";
	}
}

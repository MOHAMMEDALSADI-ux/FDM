package validator.service;

import validator.DAO.MoveFileToValidator;

public class ValidatorService {

	public void startValidator() {
		
		MoveFileToValidator fileToValidator = new MoveFileToValidator();
		fileToValidator.moveFiles();
	}
}

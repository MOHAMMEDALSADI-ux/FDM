package validator.BO;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import multipledata.GetSpecificData;

public class RemoveCSVFile {

	// TODO Method For Remove csv Files From Validator Directory
	static public void removeFiles(String pathValidator) {

		try {
			List<String> listFiles = new ArrayList<String>();

			listFiles = GetSpecificData.getListOfFiles(pathValidator);
			if (!listFiles.isEmpty()) {
				for (int i = 0; i < listFiles.size(); i++) {
					String specificFile = listFiles.get(i);

					if (specificFile.endsWith(".csv")) {
						File file = new File(specificFile);
						file.delete();
					}
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}

package validator.BO;

import java.io.BufferedWriter;
import java.io.FileWriter;

public class WriteSuccessAndRejected {

	public void success(String[] dataLine, String pathValidator, String fileName, String filePath, String delimiter,
			String tracingId) {

		String successPath = pathValidator + "\\" + "success-" + tracingId + ".val";
		BufferedWriter bufferedWriter = null;

		try {
			bufferedWriter = new BufferedWriter(new FileWriter(successPath, true));

			for (int i = 0; i < dataLine.length; i++) {
				bufferedWriter.write(dataLine[i].trim().toString() + " " + delimiter);
			}
			bufferedWriter.newLine();
			bufferedWriter.flush();
			bufferedWriter.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void rejected(String[] dataLine, String pathValidator, String fileName, String filePath, String delimiter,
			String tracingId) {

		String rejectedPath = pathValidator + "\\" + "rejected-" + tracingId + ".val";
		BufferedWriter bufferedWriter = null;

		try {
			bufferedWriter = new BufferedWriter(new FileWriter(rejectedPath, true));

			for (int i = 0; i < dataLine.length; i++) {
				bufferedWriter.write(dataLine[i].trim().toString() + " " + delimiter);
				bufferedWriter.flush();
			}

			bufferedWriter.newLine();
			bufferedWriter.flush();
			bufferedWriter.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}

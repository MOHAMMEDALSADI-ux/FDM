package validator.BO;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.io.FilenameUtils;

import multipledata.GetSpecificData;
import validator.BO.fetchtracingid.FetchTracingIdCsv;

public class ChangeFilesToOut {

	static public void changeToOut(String validatorpath) {

		try {

			List<String> listFiles = new ArrayList<String>();

			listFiles = GetSpecificData.getListOfFiles(validatorpath);
			if (!listFiles.isEmpty()) {
				for (int i = 0; i < listFiles.size(); i++) {

					String filePath = listFiles.get(i);

					if (filePath.endsWith("val")) {

						String sourceValidatorName = FilenameUtils.removeExtension(filePath);

						String pathValidatorOut = sourceValidatorName + ".out";

						File oldFile = new File(filePath);
						File newFile = new File(pathValidatorOut);
						// TODO rename the file from .val To .out
						oldFile.renameTo(newFile);

					}
				}
			}

			// TODO Get File from validator direcroty for insert into validator Table
			FetchTracingIdCsv fetchTracingIdCsv = new FetchTracingIdCsv();
			fetchTracingIdCsv.getCSVFileValidator(validatorpath);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}

package validator.BO.fetchtracingid;

import java.util.ArrayList;
import java.util.List;
import multipledata.GetSpecificData;

public class FetchTracingIdout {

	// TODO Method For get tracingId and check if this file have the same tracingId
	public void getOUTFileValidator(String tracingId, String validatorpath, String sourceFileName) {

		try {

			List<String> listFiles = new ArrayList<String>();
			listFiles = GetSpecificData.getListOfFiles(validatorpath);

			if (!listFiles.isEmpty()) {
				for (int i = 0; i < listFiles.size(); i++) {

					String outFilePath = listFiles.get(i);
					String outFileName = GetSpecificData.getFileName(outFilePath);

					if (outFilePath.endsWith(".out")) {
						// Get the tracing Id from out filename
						String tracingOut = GetSpecificData.getTracingId(outFileName);

						if (!tracingId.isEmpty() && !tracingOut.isEmpty() && tracingId.equalsIgnoreCase(tracingOut)) {

							String dateTime = GetSpecificData.datetime();

							long numberCDR = GetSpecificData.numberOfCDR(outFilePath);

							InsertToValidator insertToValidator = new InsertToValidator();
							insertToValidator.insertCsvFile(sourceFileName, outFileName, tracingId, dateTime,
									numberCDR);
						}
					}

				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}

package validator.BO.fetchtracingid;

import java.util.ArrayList;
import java.util.List;
import multipledata.GetSpecificData;
import validator.BO.RemoveCSVFile;

public class FetchTracingIdCsv {

	public void getCSVFileValidator(String validatorpath) {

		try {
			List<String> listFiles = new ArrayList<String>();

			listFiles = GetSpecificData.getListOfFiles(validatorpath);

			if (!listFiles.isEmpty()) {
				for (int i = 0; i < listFiles.size(); i++) {

					String filePath = listFiles.get(i);
					String SourceFileName = GetSpecificData.getFileName(filePath);

					if (SourceFileName.endsWith(".csv")) {

						String tracingId = GetSpecificData.getTracingId(SourceFileName);

						if (!tracingId.isEmpty()) {
							// Method For get tracingId and check if this file have the same tracingId
							FetchTracingIdout fetchTracingIdout = new FetchTracingIdout();
							fetchTracingIdout.getOUTFileValidator(tracingId, validatorpath, SourceFileName);
						}
					}
				}
			}

			RemoveCSVFile.removeFiles(validatorpath);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}

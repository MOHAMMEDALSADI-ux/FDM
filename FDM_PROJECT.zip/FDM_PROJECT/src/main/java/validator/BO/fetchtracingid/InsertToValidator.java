package validator.BO.fetchtracingid;

import java.sql.Connection;
import java.sql.PreparedStatement;

import multipledata.GetSpecificData;

public class InsertToValidator {

	public void insertCsvFile(String sourceFileName, String outFileName, String tracingId, String dateTime,
			Long numberCDR) {

		Connection connection;
		PreparedStatement preparedStatement = null;

		try {

			if (sourceFileName != null && outFileName != null && dateTime != null) {

				connection = GetSpecificData.getConnection();
				String query = "insert into fdm_validator_status (SOURCE_FILE_NAME, OUT_FILE_NAME, TRACING_ID, NUMBER_OF_CDRS, CREATE_DATE) values (?, ?, ?, ?, ?)";

				preparedStatement = connection.prepareStatement(query);

				preparedStatement.setString(1, sourceFileName.trim());
				preparedStatement.setString(2, outFileName.trim());
				preparedStatement.setString(3, tracingId);
				preparedStatement.setLong(4, numberCDR);
				preparedStatement.setString(5, dateTime.trim());
				preparedStatement.execute();

				connection.close();
				preparedStatement.close();
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}

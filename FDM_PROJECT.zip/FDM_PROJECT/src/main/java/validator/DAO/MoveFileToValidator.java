package validator.DAO;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import com.google.common.io.Files;
import main.Main;
import multipledata.GetSpecificData;

public class MoveFileToValidator {

	String pathPrs = Main.properties.getProperty("ParserFilePath");
	String validatorpath = Main.properties.getProperty("ValidatorFilePath");
	String dumperPath = Main.properties.getProperty("DumperFilePath");
	String delimiter = Main.properties.getProperty("Delimiter");
	String SourcePath = Main.properties.getProperty("SourceFilePath");
	String destinationPath = Main.properties.getProperty("DestinationFilePath");

	// TODO Method For Move File From Parser Directory To Validator Directory
	public void moveFiles() {

		List<String> listFiles = new ArrayList<String>();
		try {

			listFiles = GetSpecificData.getListOfFiles(pathPrs);

			if (!listFiles.isEmpty()) {
				for (int i = 0; i < listFiles.size(); i++) {

					String filePath = listFiles.get(i);
					String fileName = GetSpecificData.getFileName(filePath);

					if (fileName.endsWith("csv")) {

						// get the path of files
						String fromParser = filePath;
						// create path for validator directory with the file name
						String toValidator = validatorpath.toString() + "\\" + fileName;

						// Pass the (fromParser) and (toValidator) to File
						File fromParserFile = new File(fromParser);
						File toValidatorFile = new File(toValidator);
						Files.move(fromParserFile, toValidatorFile);
					}
				}
			}

			// TODO Read the “.csv” file
			ValidatorFiles.ReadCSVFile(validatorpath, delimiter);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}

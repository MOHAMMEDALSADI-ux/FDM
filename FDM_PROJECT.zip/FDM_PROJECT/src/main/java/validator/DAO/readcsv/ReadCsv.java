package validator.DAO.readcsv;

import java.io.BufferedReader;
import java.io.FileReader;
import java.sql.SQLException;

import validator.BO.WriteSuccessAndRejected;

public class ReadCsv {

	static public void readCSV(String filePath, String fileName, String pathValidator, String delimiter,
			String tracingId, String typeId) throws SQLException {

		GetTemplate.fetchRecord(typeId);

		BufferedReader bufferedReader = null;
		String valueLine = "";
		String[] dataLine = null;
		boolean condition = true;

		try {

			WriteSuccessAndRejected wSuccessAndRejected = new WriteSuccessAndRejected();

			bufferedReader = new BufferedReader(new FileReader(filePath));

			while ((valueLine = bufferedReader.readLine()) != null) {

				condition = true;
				for (int i = 0; i < GetTemplate.ListTemplate.size(); i++) {

					int order = GetTemplate.ListTemplate.get(i);

					if (valueLine != null) {
						dataLine = valueLine.split(delimiter);

						if (dataLine[order - 1].trim().equals("")) {

							condition = false;
							wSuccessAndRejected.rejected(dataLine, pathValidator, fileName, filePath, delimiter,
									tracingId);
							break;
						}
					}

				}

				if (condition && valueLine != null) {
					dataLine = valueLine.split(delimiter);
					wSuccessAndRejected.success(dataLine, pathValidator, fileName, filePath, delimiter, tracingId);
				}

				dataLine = null;

			}
			
			GetTemplate.ListTemplate.clear();
			bufferedReader.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}

package validator.DAO.readcsv;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import multipledata.GetSpecificData;

public class GetTemplate {

	static Connection connection;
	static PreparedStatement preparedStatement;
	static ResultSet resultset;

	public static List<Integer> ListTemplate = new ArrayList<Integer>();

	static public void fetchRecord(String typeId) throws SQLException {

		try {

			connection = GetSpecificData.getConnection();
			String selectTemplate = "SELECT * FROM dumper_manager.fdm_template_file WHERE TYPE_ID = " + typeId
					+ " and IS_CONDITIONAL_TAG = true";

			preparedStatement = connection.prepareStatement(selectTemplate);

			resultset = preparedStatement.executeQuery();

			while (resultset.next()) {

				int order = resultset.getInt("ORDER");

				ListTemplate.add(order);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		resultset.close();
		preparedStatement.close();
		connection.close();
	}

}

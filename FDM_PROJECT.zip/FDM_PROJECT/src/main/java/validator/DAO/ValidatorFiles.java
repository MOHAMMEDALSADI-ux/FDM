package validator.DAO;

import java.util.ArrayList;
import java.util.List;
import multipledata.GetSpecificData;
import multipledata.GetTypeOfFile;
import validator.BO.ChangeFilesToOut;
import validator.DAO.readcsv.ReadCsv;

public class ValidatorFiles {

	// TODO Read the “.csv” file
	static public void ReadCSVFile(String validatorpath, String delimiter) {

		List<String> listFiles = new ArrayList<String>();
		try {

			listFiles = GetSpecificData.getListOfFiles(validatorpath);

			if (!listFiles.isEmpty()) {

				for (int i = 0; i < listFiles.size(); i++) {

					String filePath = listFiles.get(i);
					String fileName = GetSpecificData.getFileName(filePath);

					if (fileName.endsWith("csv")) {

						// Get the Tracing Id of the file
						String tracingId = GetSpecificData.getTracingId(fileName);

						// Method For get type of file if its json or xml
						GetTypeOfFile typeOfFile = new GetTypeOfFile();
						String typeId = typeOfFile.typeIdForFile(tracingId);

						if (!tracingId.isEmpty() && typeId.equals("2") || typeId.equals("1")) {
							// TODO Method For Read Json File
							ReadCsv.readCSV(filePath, fileName, validatorpath, delimiter, tracingId, typeId);
						}

					}
				}
			}

			// TODO Chenge Files (success and rejected) To .out
			ChangeFilesToOut.changeToOut(validatorpath);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}

package parser.models;

public class FDM_TYPES {

	int id;
	String types;

	public FDM_TYPES() {
		super();
	}

	public FDM_TYPES(int id, String types) {
		super();
		this.id = id;
		this.types = types;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTypes() {
		return types;
	}

	public void setTypes(String types) {
		this.types = types;
	}

	@Override
	public String toString() {
		return "FDM_TYPES [id=" + id + ", types=" + types + "]";
	}

}

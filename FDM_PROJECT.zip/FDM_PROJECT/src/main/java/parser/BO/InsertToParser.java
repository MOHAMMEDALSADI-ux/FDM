package parser.BO;

import java.io.File;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;
import multipledata.GetSpecificData;

public class InsertToParser {

	// TODO Get Information of the file for Insert info Parser Table
	static public void getFilesParser(String pathPrs, String destinationPath) {

		List<String> listFiles = new ArrayList<String>();
		File fileParser = null;
		try {

			listFiles = GetSpecificData.getListOfFiles(pathPrs);
			if (!listFiles.isEmpty()) {
				for (int i = 0; i < listFiles.size(); i++) {

					String filePath = listFiles.get(i);
					String fileName = GetSpecificData.getFileName(filePath);

					// Create Date and Time For DataBase Record
					String dateTime = GetSpecificData.datetime();

					// For read Number Of CRE in this file
					long numberCdr = GetSpecificData.numberOfCDR(filePath);

					fileParser = new File(filePath);

					if (fileParser.exists()) {

						// For Get TypeId
						String typeId = GetSpecificData.getTypeId(fileName);
						// For Get TracingId
						String trasingId = GetSpecificData.getTracingId(fileName);

						// For get only file name
						String sourceFileName = GetSpecificData.getSourceFileName(fileName);

						if (fileName.endsWith("csv") && !fileName.isEmpty() && !sourceFileName.isEmpty()
								&& !trasingId.isEmpty() && !dateTime.isEmpty() && !typeId.isEmpty()
								&& !(numberCdr + "").isEmpty()) {
							logIntoDatabase(fileName, sourceFileName, trasingId, dateTime, typeId, numberCdr);
						}

					}
				}
			}
			// TODO add .Done to names files in Destination Directory
			AddDone.changeFileDone(destinationPath);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// TODO Log the file into database “FDM_PARSER_STATUS”
	static public void logIntoDatabase(String outFileName, String sourceFileName, String trasingId, String dateTime,
			String typeId, long numberCdr) {

		PreparedStatement preparedStatement = null;
		Connection connection;

		int type = Integer.parseInt(typeId);

		try {
			connection = GetSpecificData.getConnection();
			String query = "insert into fdm_parser_status (SOURCE_FILE_NAME, OUT_FILE_NAME, TRACING_ID, NUMBER_OF_CDRS, CREATE_DATE, TYPE_ID) values (?, ?, ?, ?, ?, ?)";

			preparedStatement = connection.prepareStatement(query);

			preparedStatement.setString(1, sourceFileName);
			preparedStatement.setString(2, outFileName);
			preparedStatement.setString(3, trasingId);
			preparedStatement.setLong(4, numberCdr);
			preparedStatement.setString(5, dateTime);
			preparedStatement.setInt(6, type);
			preparedStatement.execute();

			preparedStatement.close();
			connection.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}

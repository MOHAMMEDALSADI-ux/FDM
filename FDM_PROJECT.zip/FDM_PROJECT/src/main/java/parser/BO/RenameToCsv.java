package parser.BO;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.io.FilenameUtils;
import multipledata.GetSpecificData;

public class RenameToCsv {

	static public void ToCsv(String parserPath, String delimiter, String destinationPath) {
		List<String> listFiles = new ArrayList<String>();

		try {

			listFiles = GetSpecificData.getListOfFiles(parserPath);
			if (!listFiles.isEmpty()) {
				for (int i = 0; i < listFiles.size(); i++) {

					String filePath = listFiles.get(i);

					if (filePath.endsWith(".prs")) {

						String fileRemoveExtention = FilenameUtils.removeExtension(filePath);

						String newPath = fileRemoveExtention + ".csv";

						File oldFile = new File(filePath);
						File newFile = new File(newPath);

						if (!oldFile.renameTo(newFile)) {
							i = i - 1;
						}
					}

				}
			}
			// TODO Get Files From Parser Folder and Insert the Information to Table
			InsertToParser.getFilesParser(parserPath, destinationPath);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}

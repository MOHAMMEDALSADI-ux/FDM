package parser.BO;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Map;

import org.apache.commons.io.FilenameUtils;

import multipledata.GetSpecificData;

public class CreatePrsFile {

	PreparedStatement preparedStatement = null;
	Connection connection = null;
	ResultSet resultSet = null;
	ArrayList<String> TAG_NAME = new ArrayList<String>();

	// TODO Method For get tagNames for files xml and json
	public ArrayList<String> getTagNames(int TYPE_ID) {

		try {

			connection = GetSpecificData.getConnection();

			String query = "SELECT * FROM dumper_manager.fdm_template_file where TYPE_ID = " + TYPE_ID + "";

			preparedStatement = connection.prepareStatement(query);

			resultSet = preparedStatement.executeQuery();

			while (resultSet.next()) {
				TAG_NAME.add(resultSet.getString("TAG_NAME"));
			}

			resultSet.close();
			preparedStatement.close();
			connection.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return TAG_NAME;
	}

	// TODO Method For write data in parser File
	public void writeToPrs(String delimiter, Map<String, String> map, String parserPath, String filePath,
			String fileName, String uniqueID, ArrayList<String> tagName, int TYPE_ID) {

		try {
			String fileWithoutExtension = FilenameUtils.removeExtension(fileName);

			// create file path for parser file
			String newFileParserPath = parserPath + "/" + fileWithoutExtension + "-" + TYPE_ID + "-" + uniqueID
					+ ".prs";

			BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(newFileParserPath, true));

			// Check if the arrayList is Empty
			if (!tagName.isEmpty()) {

				// loop for get the data from map
				for (int i = 0; i < tagName.size(); i++) {

					if (map.get(tagName.get(i).toLowerCase()) == null) {
						bufferedWriter.write("" + " " + delimiter + " ");
					} else {
						bufferedWriter
								.write(map.get(tagName.get(i).toLowerCase()).replace(",", " ") + " " + delimiter + " ");
					}

				}
				bufferedWriter.write(fileName);
				bufferedWriter.newLine();
				bufferedWriter.flush();
			}

			bufferedWriter.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}

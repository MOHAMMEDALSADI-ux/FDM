package parser.BO;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import multipledata.GetSpecificData;

public class AddDone {

	// TODO Rename the files name in the destination directory by add “.DONE”
	static public void changeFileDone(String DestinationPath) {

		try {
			List<String> listFiles = new ArrayList<String>();

			listFiles = GetSpecificData.getListOfFiles(DestinationPath);

			if (!listFiles.isEmpty()) {

				for (int i = 0; i < listFiles.size(); i++) {

					String filePath = listFiles.get(i);
					String fileName = GetSpecificData.getFileName(filePath);

					if (!fileName.endsWith(".DONE")) {

						String newDistinationName = filePath + ".DONE";

						if (!newDistinationName.isEmpty()) {

							File oldFiles = new File(filePath);
							File newFiles = new File(newDistinationName);

							oldFiles.renameTo(newFiles);

						}
					}
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}

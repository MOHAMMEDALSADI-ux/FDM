package parser.service;

import parser.DAO.MoveFileSource;

public class ParserService {

	// TODO Service Class For parser Part
	public void startParser() {
		MoveFileSource moveSource = new MoveFileSource();
		moveSource.moveFileToDestination();
		
	}
}

package parser.DAO;

import java.io.File;
import java.io.UncheckedIOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import main.Main;
import multipledata.GetSpecificData;

public class MoveFileSource {

	String pathPrs = Main.properties.getProperty("ParserFilePath");
	String validatorpath = Main.properties.getProperty("ValidatorFilePath");
	String dumperPath = Main.properties.getProperty("DumperFilePath");
	String delimiter = Main.properties.getProperty("Delimiter");
	String SourcePath = Main.properties.getProperty("SourceFilePath");
	String destinationPath = Main.properties.getProperty("DestinationFilePath");

	// TODO Move the files to the destination directory “./Destination”.
	public void moveFileToDestination() {
		List<String> listfile = new ArrayList<String>();

		try {

			// TODO Method For Get List Of Files
			listfile = GetSpecificData.getListOfFileLastModified(SourcePath);

			// Method For Create Directory if not exists
			MoveFileSource moveFileSource = new MoveFileSource();
			moveFileSource.createDirectory();

			if (!listfile.isEmpty()) {

				for (int i = 0; i < listfile.size(); i++) {

					String filePath = listfile.get(i);

					if (filePath.endsWith(".xml") || filePath.endsWith(".json")) {

						String toDestination = destinationPath + "\\"
								+ GetSpecificData.getFileName(filePath);

						Files.move(Paths.get(filePath), Paths.get(toDestination));

					}
				}
			}

			
			// TODO Read Files From Destination Folder
			ReadFiles readFiles = new ReadFiles();
			readFiles.getFiles(delimiter, pathPrs, destinationPath);

		} catch (UncheckedIOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	// TODO Create All Directory
	private void createDirectory() {

		File destinationDirectory = new File(destinationPath);
		File sourceDirectory = new File(SourcePath);
		File validatorDirectory = new File(validatorpath);
		File parserDirectory = new File(pathPrs);
		File dumperDirectory = new File(dumperPath);

		if (!sourceDirectory.exists())
			sourceDirectory.mkdir();

		if (!destinationDirectory.exists())
			destinationDirectory.mkdir();

		if (!parserDirectory.exists())
			parserDirectory.mkdir();

		if (!validatorDirectory.exists())
			validatorDirectory.mkdir();

		if (!dumperDirectory.exists())
			dumperDirectory.mkdir();

	}
}

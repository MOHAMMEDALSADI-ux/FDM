package parser.DAO.xmlfile;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import multipledata.GetSpecificData;
import parser.BO.CreatePrsFile;

public class ParserJson {

	static public void parserJsonFiles(String filePath, String delimiter, String fileName, String pathPrs)
			throws IOException {

		// Create jsonParser Object
		JSONParser jsonParser = new JSONParser();
		// creating JSONObject
		JSONObject jsonObject;
		// Typeid of json files
		int TYPE_ID = 2;
		// Collections
		Map<String, String> jsonMap = new HashMap<String, String>();
		ArrayList<String> tagName = new ArrayList<String>();

		try {

			// Read the File Path Destination
			File file = new File(filePath);

			// Mathod For Get Tags Name From Template Table for Json File
			CreatePrsFile createPrsFile = new CreatePrsFile();
			tagName = createPrsFile.getTagNames(TYPE_ID);

			if (file.length() != 0) {

				FileReader fileReader = new FileReader(filePath);

				Object obj = jsonParser.parse(fileReader);

				// Josn Array
				JSONArray jsonArray = (JSONArray) obj;

				String uniqueID = GetSpecificData.createTracingId();

				// check if the JOSNArray null or not
				if (jsonArray != null) {

					// loop for get key and value from jsonArray
					@SuppressWarnings("unchecked")
					Iterator<Object> iterator = jsonArray.iterator();

					while (iterator.hasNext()) {
						jsonObject = (JSONObject) iterator.next();
						for (Object key : jsonObject.keySet()) {
							jsonMap.put(key.toString().toLowerCase(), jsonObject.get(key).toString());
						}

						createPrsFile.writeToPrs(delimiter, jsonMap, pathPrs, filePath, fileName, uniqueID, tagName,
								TYPE_ID);
						jsonMap.clear();
					}

				}
				fileReader.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}

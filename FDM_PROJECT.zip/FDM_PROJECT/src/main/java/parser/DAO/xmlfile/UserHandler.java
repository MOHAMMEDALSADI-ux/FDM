package parser.DAO.xmlfile;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import parser.BO.CreatePrsFile;

public class UserHandler extends DefaultHandler {

	boolean id = false;
	boolean name = false;
	boolean lastname = false;
	boolean bdate = false;
	boolean nationalid = false;
	boolean phone = false;
	boolean gender = false;
	boolean address = false;

	String filePath, fileName, delimiter, parserPath, uniqueId;

	String ID, Name, LastName, BDate, NationalId, Phone, Gender, Address;

	int TYPE_ID;

	public static Map<String, String> Xmlmap = new HashMap<String, String>();
	ArrayList<String> tagName = new ArrayList<String>();

	public UserHandler(String file_Path, String file_name, String delimiter, String parser_path, String uniqueID,
			ArrayList<String> tagName, int TYPE_ID) {
		this.fileName = file_name;
		this.filePath = file_Path;
		this.delimiter = delimiter;
		this.parserPath = parser_path;
		this.uniqueId = uniqueID;
		this.tagName = tagName;
		this.TYPE_ID = TYPE_ID;

	}

	@Override
	public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
		super.startElement(uri, localName, qName, attributes);

		// save the tag name into variable for get the specific data from Map
		if (qName.equalsIgnoreCase("ID")) {
			ID = qName;
			id = true;
		} else if (qName.equalsIgnoreCase("Name")) {
			Name = qName;
			name = true;
		} else if (qName.equalsIgnoreCase("LastName")) {
			LastName = qName;
			lastname = true;
		} else if (qName.equalsIgnoreCase("BDate")) {
			BDate = qName;
			bdate = true;
		} else if (qName.equalsIgnoreCase("NationalID")) {
			NationalId = qName;
			nationalid = true;
		} else if (qName.equalsIgnoreCase("Phone")) {
			Phone = qName;
			phone = true;
		} else if (qName.equalsIgnoreCase("Gender")) {
			Gender = qName;
			gender = true;
		} else if (qName.equalsIgnoreCase("Address")) {
			Address = qName;
			address = true;
		}

	}

	@Override
	public void endElement(String uri, String localName, String qName) throws SAXException {
		super.endElement(uri, localName, qName);

		if (qName.equalsIgnoreCase("CDR")) {

			try {

				// TODO Method For write data in parser File
				CreatePrsFile createPrsFile = new CreatePrsFile();
				createPrsFile.writeToPrs(delimiter, Xmlmap, parserPath, filePath, fileName, uniqueId, tagName, TYPE_ID);
				Xmlmap.clear();

			} catch (Exception e) {
				e.printStackTrace();
			}

		}
	}

	@Override
	public void characters(char[] ch, int start, int length) throws SAXException {
		super.characters(ch, start, length);

		// put or save the data into the Map
		if (id) {
			Xmlmap.put(ID.toLowerCase(), new String(ch, start, length).trim());
			id = false;
		} else if (name) {
			Xmlmap.put(Name.toLowerCase(), new String(ch, start, length).trim());
			name = false;
		} else if (lastname) {
			Xmlmap.put(LastName.toLowerCase(), new String(ch, start, length).trim());
			lastname = false;
		} else if (bdate) {
			Xmlmap.put(BDate.toLowerCase(), new String(ch, start, length).trim());
			bdate = false;
		} else if (nationalid) {
			Xmlmap.put(NationalId.toLowerCase(), new String(ch, start, length).trim());
			nationalid = false;
		} else if (phone) {
			Xmlmap.put(Phone.toLowerCase(), new String(ch, start, length).trim());
			phone = false;
		} else if (gender) {
			Xmlmap.put(Gender.toLowerCase(), new String(ch, start, length).trim());
			gender = false;
		} else if (address) {
			Xmlmap.put(Address.toLowerCase(), new String(ch, start, length).trim());
			address = false;
		}

	}
}

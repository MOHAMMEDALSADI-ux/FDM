package parser.DAO;

import java.util.ArrayList;
import java.util.List;
import multipledata.GetSpecificData;
import parser.BO.RenameToCsv;
import parser.DAO.jsonfile.ParserXml;
import parser.DAO.xmlfile.ParserJson;

public class ReadFiles {

	// TODO Get Files From Destination Directory
	public void getFiles(String delimiter, String pathPrs, String destinationPath) {

		List<String> listFiles = new ArrayList<String>();

		try {

			// TODO Method For Get List Of Files
			listFiles = GetSpecificData.getListOfFiles(destinationPath);

			if (!listFiles.isEmpty()) {
				for (int i = 0; i < listFiles.size(); i++) {

					String filePath = listFiles.get(i);
					String fileName = GetSpecificData.getFileName(filePath);

					if (!filePath.isEmpty() && filePath.endsWith("xml")) {

						ParserXml.parserXmlFiles(filePath, fileName, delimiter, pathPrs);

					} else if (!filePath.isEmpty() && filePath.endsWith("json")) {

						ParserJson.parserJsonFiles(filePath, delimiter, fileName, pathPrs);

					}
				}
			}

			// TODO Change extention File From .prs To .csv in Parser Directory
			RenameToCsv.ToCsv(pathPrs, delimiter, destinationPath);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}

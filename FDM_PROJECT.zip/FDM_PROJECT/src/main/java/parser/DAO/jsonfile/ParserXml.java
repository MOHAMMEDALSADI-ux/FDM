package parser.DAO.jsonfile;

import java.io.File;
import java.util.ArrayList;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import multipledata.GetSpecificData;
import parser.BO.CreatePrsFile;
import parser.DAO.xmlfile.UserHandler;

public class ParserXml {

	// TODO Read the XML file
	static public void parserXmlFiles(String filePath, String fileName, String delimiter, String pathPrs) {
		int TYPE_ID = 1;
		try {

			// ArrayList For save the tagNames
			ArrayList<String> tagName = new ArrayList<String>();

			File inputFile = new File(filePath);

			// Mathod For Get Tags Name From Template Table for xml File
			CreatePrsFile createPrsFile = new CreatePrsFile();
			tagName = createPrsFile.getTagNames(TYPE_ID);

			// Set The unique random number
			String uniqueID = GetSpecificData.createTracingId();

			// Check if the file in Empty or not
			if (inputFile.length() != 0) {
				SAXParserFactory factory = SAXParserFactory.newInstance();

				SAXParser saxParser = factory.newSAXParser();

				UserHandler userHandler = new UserHandler(filePath, fileName, delimiter, pathPrs, uniqueID, tagName,
						TYPE_ID);

				saxParser.parse(inputFile, userHandler);
			}

		} catch (Exception e) {
			e.getMessage();
		}
	}

}

package main;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import dumper.service.DumperService;
import multipledata.LoadTables;
import parser.service.ParserService;
import validator.service.ValidatorService;

public class Main {

	public static Properties properties;

	// TODO Load properties file.
	static {
		properties = new Properties();

		try {

			// Read Propertie File
			FileInputStream fileInputStream = new FileInputStream(
					"C:\\Users\\m.alsadi\\eclipse-workspace\\FDM_PROJECT\\resources\\config.properties");
			BufferedInputStream bufferedInputStream = new BufferedInputStream(fileInputStream);

			properties.load(bufferedInputStream);

			bufferedInputStream.close();
			fileInputStream.close();

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException io) {
			io.printStackTrace();
		}
	}

	public static void main(String[] args) {

		LoadTables.loadTable();

		// Thread For Parser Part
		Runnable parserRunnable = new Runnable() {

			public void run() {
				// TODO Move the files to the Destination directory “./Destination”.
				ParserService parserService = new ParserService();
				parserService.startParser();
			}
		};

		// Thread For Validator Part
		Runnable validatorRunnable = new Runnable() {

			public void run() {
				// TODO Move the files to the Validator directory “./Validator”.
				ValidatorService validatorService = new ValidatorService();
				validatorService.startValidator();

			}
		};

		// Thread For Dumper part
		Runnable dumperRunnable = new Runnable() {

			public void run() {
				// TODO Move the files to the Dumper directory “./Dumper”.
				DumperService dumperService = new DumperService();
				dumperService.startDumper();

			}
		};

		while (true) {

			parserRunnable.run();
			validatorRunnable.run();
			dumperRunnable.run();

		}

	}
}

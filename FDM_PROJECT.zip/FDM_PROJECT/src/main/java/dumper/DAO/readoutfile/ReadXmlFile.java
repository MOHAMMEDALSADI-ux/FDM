package dumper.DAO.readoutfile;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import dumper.BO.inserttotables.InsertToDumperStatus;
import dumper.BO.inserttotables.InsertToXmlDumper;
import dumper.models.Fdm_Xml_Dumper;
import multipledata.GetSpecificData;

public class ReadXmlFile {

	public static List<Fdm_Xml_Dumper> Xml_List = new ArrayList<Fdm_Xml_Dumper>();

	// TODO Read XML Out File
	static public void readXml(String fileName, String filePath, String delimiter, String tracingId) {

		String record = "";
		String dateTime = "";
		String[] dataLine = null;
		HashMap<Integer, String> hashData = new HashMap<Integer, String>();
		BufferedReader bufferedReader = null;

		try {

			bufferedReader = new BufferedReader(new FileReader(filePath));

			while ((record = bufferedReader.readLine()) != null) {

				dataLine = record.split(delimiter);

				for (int i = 0; i < dataLine.length; i++) {
					hashData.put(i, dataLine[i]);
				}

				// Create Date and Time For DataBase Record
				dateTime = GetSpecificData.datetime();

				Fdm_Xml_Dumper fdm_Xml_Dumper = new Fdm_Xml_Dumper();

				fdm_Xml_Dumper.setCdr_Id(hashData.get(0));
				fdm_Xml_Dumper.setName(hashData.get(1));
				fdm_Xml_Dumper.setLast_Name(hashData.get(2));
				fdm_Xml_Dumper.setB_Date(hashData.get(3));
				fdm_Xml_Dumper.setNational_Id(hashData.get(4));
				fdm_Xml_Dumper.setPhone(hashData.get(5));
				fdm_Xml_Dumper.setGender(hashData.get(6));
				fdm_Xml_Dumper.setAddress(hashData.get(7));
				fdm_Xml_Dumper.setFilename(fileName);
				fdm_Xml_Dumper.setCreate_date(dateTime);

				Xml_List.add(fdm_Xml_Dumper);

			}

			InsertToXmlDumper.insertXmlList(dateTime, fileName, Xml_List);

			Xml_List.clear();
			bufferedReader.close();

			// For read Number Of CRE in this file
			long numberCdr = GetSpecificData.numberOfCDR(filePath);

			InsertToDumperStatus.insertOutFile(fileName, tracingId, numberCdr, dateTime);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}

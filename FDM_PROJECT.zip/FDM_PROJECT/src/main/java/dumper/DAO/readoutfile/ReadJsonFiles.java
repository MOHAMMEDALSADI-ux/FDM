package dumper.DAO.readoutfile;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import dumper.BO.inserttotables.InsertToDumperStatus;
import dumper.BO.inserttotables.InsertToJsonDumper;
import dumper.models.Fdm_Json_Dumper;
import multipledata.GetSpecificData;

public class ReadJsonFiles {

	public static List<Fdm_Json_Dumper> Json_List = new ArrayList<Fdm_Json_Dumper>();

	// TODO Read JSON Out File
	static public void readJson(String fileName, String filePath, String delimiter, String tracingId) {

		String record = "";
		String dateTime = "";
		String[] dataLine = null;
		HashMap<Integer, String> hashData = new HashMap<Integer, String>();
		BufferedReader bufferedReader = null;

		try {

			bufferedReader = new BufferedReader(new FileReader(filePath));

			while ((record = bufferedReader.readLine()) != null) {
				dataLine = record.split(delimiter);

				for (int i = 0; i < dataLine.length; i++) {
					hashData.put(i, dataLine[i]);
				}

				// Create Date and Time For DataBase Record
				dateTime = GetSpecificData.datetime();

				Fdm_Json_Dumper fdm_Json_Dumper = new Fdm_Json_Dumper();

				fdm_Json_Dumper.setCdr_Id(hashData.get(0));
				fdm_Json_Dumper.setName(hashData.get(1));
				fdm_Json_Dumper.setLast_Name(hashData.get(2));
				fdm_Json_Dumper.setB_Date(hashData.get(3));
				fdm_Json_Dumper.setNational_Id(hashData.get(4));
				fdm_Json_Dumper.setPhone(hashData.get(5));
				fdm_Json_Dumper.setGender(hashData.get(6));
				fdm_Json_Dumper.setFile_Name(fileName);
				fdm_Json_Dumper.setCreate_Date(dateTime);

				Json_List.add(fdm_Json_Dumper);

				InsertToJsonDumper.insertJsonLine(Json_List);

				Json_List.clear();
			}

			bufferedReader.close();

			// For read Number Of CRE in this file
			long numberCdr = GetSpecificData.numberOfCDR(filePath);

			InsertToDumperStatus.insertOutFile(fileName, tracingId, numberCdr, dateTime);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}

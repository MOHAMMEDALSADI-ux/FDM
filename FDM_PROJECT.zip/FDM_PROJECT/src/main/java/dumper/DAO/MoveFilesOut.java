package dumper.DAO;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import com.google.common.io.Files;
import main.Main;
import multipledata.GetSpecificData;

public class MoveFilesOut {

	String pathPrs = Main.properties.getProperty("ParserFilePath");
	String validatorpath = Main.properties.getProperty("ValidatorFilePath");
	String dumperPath = Main.properties.getProperty("DumperFilePath");
	String delimiter = Main.properties.getProperty("Delimiter");
	String SourcePath = Main.properties.getProperty("SourceFilePath");
	String destinationPath = Main.properties.getProperty("DestinationFilePath");

	// TODO Move the files to “./Dumper”
	public void fileToDumper() {

		try {

			List<String> listFiles = new ArrayList<String>();
			listFiles = GetSpecificData.getListOfFiles(validatorpath);

			if (!listFiles.isEmpty()) {
				for (int i = 0; i < listFiles.size(); i++) {
					String specificFile = listFiles.get(i);
					String fileName = GetSpecificData.getFileName(specificFile);

					if (!fileName.isEmpty() && fileName.endsWith("out")) {

						String fromValidator = specificFile;
						String toDumper = dumperPath.toString() + "\\" + fileName;

						File fromValidatorFile = new File(fromValidator);
						File toDumperFile = new File(toDumper);
						Files.move(fromValidatorFile, toDumperFile);
					}
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		ReadFiles.getTypeOutFile(dumperPath, delimiter);
	}
}

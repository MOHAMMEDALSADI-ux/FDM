package dumper.DAO;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

import dumper.BO.inserttotables.InsertToDumperStatus;
import dumper.BO.inserttotables.InsertToRejectedDumper;
import dumper.models.Fdm_rejected_Dumper;
import multipledata.GetSpecificData;

public class ReadRejectedFile {

	public static List<Fdm_rejected_Dumper> Rejected_List = new ArrayList<Fdm_rejected_Dumper>();

	static public void readRejectedFiles(String tracingId, String fileName, String filePath, String delimiter) {

		String record = "";
		String dateTime = "";
		BufferedReader bufferedReader = null;

		try {
			bufferedReader = new BufferedReader(new FileReader(filePath));

			while ((record = bufferedReader.readLine()) != null) {

				// Create Date and Time For DataBase Record
				dateTime = GetSpecificData.datetime();

				Fdm_rejected_Dumper fdm_rejected_Dumper = new Fdm_rejected_Dumper();

				fdm_rejected_Dumper.setCdr(record);
				fdm_rejected_Dumper.setFile_name(fileName);
				fdm_rejected_Dumper.setCreate_date(dateTime);

				Rejected_List.add(fdm_rejected_Dumper);

				InsertToRejectedDumper.insertRejectedFile(Rejected_List);

				Rejected_List.clear();
			}

			// For read Number Of CRE in this file
			long numberCdr = GetSpecificData.numberOfCDR(filePath);

			InsertToDumperStatus.insertOutFile(fileName, tracingId, numberCdr, dateTime);

			bufferedReader.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}

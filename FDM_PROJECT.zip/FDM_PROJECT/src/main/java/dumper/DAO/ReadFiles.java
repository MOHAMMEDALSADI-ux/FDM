package dumper.DAO;

import java.util.ArrayList;
import java.util.List;
import dumper.BO.RemoveOUTFile;
import dumper.DAO.readoutfile.ReadJsonFiles;
import dumper.DAO.readoutfile.ReadXmlFile;
import multipledata.GetSpecificData;
import multipledata.GetTypeOfFile;

public class ReadFiles {

	// TODO Get The Type of File it is XML or JSON
	static public void getTypeOutFile(String dumperPath, String delimiter) {

		try {
			List<String> listFiles = new ArrayList<String>();
			listFiles = GetSpecificData.getListOfFiles(dumperPath);

			if (!listFiles.isEmpty()) {
				for (int i = 0; i < listFiles.size(); i++) {
					String specificFile = listFiles.get(i);
					
					String fileName = GetSpecificData.getFileName(specificFile);

					String tracingId = GetSpecificData.getTracingId(fileName);

					if (!tracingId.isEmpty() && fileName.startsWith("success")) {
						verifyTracingId(tracingId, fileName, specificFile, delimiter);
					} else if (!tracingId.isEmpty() && fileName.startsWith("rejected")) {
						ReadRejectedFile.readRejectedFiles(tracingId, fileName, specificFile, delimiter);
					}
				}
			}
			// TODO Delete Files That end with .out From Dumper Directory
			RemoveOUTFile.removeFiles(dumperPath);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	static public void verifyTracingId(String tracingId, String fileName, String filePath, String delimiter) {

		try {

			// Method for get the typeid of file from parser table
			GetTypeOfFile typeOfFile = new GetTypeOfFile();
			String typeId = typeOfFile.typeIdForFile(tracingId);

			if (!typeId.isEmpty() && typeId.equalsIgnoreCase("2")) {

				ReadJsonFiles.readJson(fileName, filePath, delimiter, tracingId);

			} else if (!typeId.isEmpty() && typeId.equalsIgnoreCase("1")) {

				ReadXmlFile.readXml(fileName, filePath, delimiter, tracingId);

			}

		} catch (

		Exception e) {
			e.printStackTrace();
		}
	}
}

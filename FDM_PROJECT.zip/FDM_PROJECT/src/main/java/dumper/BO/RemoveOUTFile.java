package dumper.BO;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import multipledata.GetSpecificData;

public class RemoveOUTFile {

	static public void removeFiles(String dumperPath) {

		try {
			List<String> listFiles = new ArrayList<String>();
			listFiles = GetSpecificData.getListOfFiles(dumperPath);

			if (!listFiles.isEmpty()) {
				for (int i = 0; i < listFiles.size(); i++) {

					String specificFile = listFiles.get(i);
					String fileName = GetSpecificData.getFileName(specificFile);

					if (!fileName.isEmpty()) {
						File file = new File(specificFile);
						file.delete();
					}
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}

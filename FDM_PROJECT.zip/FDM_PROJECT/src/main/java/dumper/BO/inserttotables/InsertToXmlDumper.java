package dumper.BO.inserttotables;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.List;

import dumper.models.Fdm_Xml_Dumper;
import multipledata.GetSpecificData;

public class InsertToXmlDumper {

	static public void insertXmlList(String dateTime, String fileName, List<Fdm_Xml_Dumper> Xml_List) {

		PreparedStatement preparedStatement = null;
		Connection connection;

		try {
			connection = GetSpecificData.getConnection();
			String query = "insert into fdm_xml_dumper (CDR_ID, NAME, LAST_NAME, B_DATE, NATIONAL_ID, PHONE , GENDER , ADDRESS , FILE_NAME , CREATE_DATE) values (?, ?, ?, ?, ?, ? , ? , ? , ? , ?)";

			for (int i = 0; i < Xml_List.size(); i++) {

				preparedStatement = connection.prepareStatement(query);

				preparedStatement.setString(1, Xml_List.get(i).getCdr_Id());
				preparedStatement.setString(2, Xml_List.get(i).getName());
				preparedStatement.setString(3, Xml_List.get(i).getLast_Name());
				preparedStatement.setString(4, Xml_List.get(i).getB_Date());
				preparedStatement.setString(5, Xml_List.get(i).getNational_Id());
				preparedStatement.setString(6, Xml_List.get(i).getPhone());
				preparedStatement.setString(7, Xml_List.get(i).getGender());
				preparedStatement.setString(8, Xml_List.get(i).getAddress());
				preparedStatement.setString(9, Xml_List.get(i).getFilename());
				preparedStatement.setString(10, Xml_List.get(i).getCreate_date());
				preparedStatement.execute();
			}

			connection.close();
			preparedStatement.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}

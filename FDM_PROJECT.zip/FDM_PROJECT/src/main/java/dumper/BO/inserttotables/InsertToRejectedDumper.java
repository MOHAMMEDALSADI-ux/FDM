package dumper.BO.inserttotables;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.List;

import dumper.models.Fdm_rejected_Dumper;
import multipledata.GetSpecificData;

public class InsertToRejectedDumper {

	static public void insertRejectedFile(List<Fdm_rejected_Dumper> Rejected_List) {

		PreparedStatement preparedStatement = null;
		Connection connection;

		try {
			connection = GetSpecificData.getConnection();
			String query = "insert into fdm_rejected_dumper (CDR, FILE_NAME, CREATE_DATE) values (?, ?, ?)";

			for (int i = 0; i < Rejected_List.size(); i++) {

				preparedStatement = connection.prepareStatement(query);

				preparedStatement.setString(1, Rejected_List.get(i).getCdr());
				preparedStatement.setString(2, Rejected_List.get(i).getFile_name());
				preparedStatement.setString(3, Rejected_List.get(i).getCreate_date());
				preparedStatement.execute();
			}

			preparedStatement.close();
			connection.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}

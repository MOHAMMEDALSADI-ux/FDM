package dumper.BO.inserttotables;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.List;

import dumper.models.Fdm_Json_Dumper;
import multipledata.GetSpecificData;

public class InsertToJsonDumper {

	static public void insertJsonLine(List<Fdm_Json_Dumper> Json_List) {

		PreparedStatement preparedStatement = null;
		Connection connection;

		try {
			connection = GetSpecificData.getConnection();
			String query = "insert into fdm_json_dumper (CDR_ID, NAME, LAST_NAME, B_DATE, NATIONAL_ID, PHONE , GENDER , FILE_NAME , CREATE_DATE) values (?, ?, ?, ?, ?, ? , ? , ? , ?)";

			preparedStatement = connection.prepareStatement(query);

			preparedStatement.setString(1, Json_List.get(0).getCdr_Id());
			preparedStatement.setString(2, Json_List.get(0).getName());
			preparedStatement.setString(3, Json_List.get(0).getLast_Name());
			preparedStatement.setString(4, Json_List.get(0).getB_Date());
			preparedStatement.setString(5, Json_List.get(0).getNational_Id());
			preparedStatement.setString(6, Json_List.get(0).getPhone());
			preparedStatement.setString(7, Json_List.get(0).getGender());
			preparedStatement.setString(8, Json_List.get(0).getFile_Name());
			preparedStatement.setString(9, Json_List.get(0).getCreate_Date());
			preparedStatement.execute();

			preparedStatement.close();
			connection.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}

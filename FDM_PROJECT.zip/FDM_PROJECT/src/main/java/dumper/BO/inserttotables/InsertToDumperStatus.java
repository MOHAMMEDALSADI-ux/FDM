package dumper.BO.inserttotables;

import java.sql.Connection;
import java.sql.PreparedStatement;
import multipledata.GetSpecificData;

public class InsertToDumperStatus {

	static public void insertOutFile(String fileName, String tracingId, long numberCdr, String dateTime) {

		Connection connection;
		PreparedStatement preparedStatement = null;
		try {

			connection = GetSpecificData.getConnection();
			String query = "insert into fdm_dumper_status (SOURCE_FILE_NAME, TRACING_ID, NUMBER_OF_CDRS , CREATE_DATE ) values (?, ?, ?, ?)";

			preparedStatement = connection.prepareStatement(query);

			preparedStatement.setString(1, fileName);
			preparedStatement.setString(2, tracingId);
			preparedStatement.setLong(3, numberCdr);
			preparedStatement.setString(4, dateTime);

			preparedStatement.execute();

			preparedStatement.close();
			connection.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}

package dumper.models;

public class Fdm_rejected_Dumper {

	String cdr, file_name, create_date;

	public Fdm_rejected_Dumper(String cdr, String file_name, String create_date) {
		super();
		this.cdr = cdr;
		this.file_name = file_name;
		this.create_date = create_date;
	}

	public Fdm_rejected_Dumper() {
		super();
	}

	public String getCdr() {
		return cdr;
	}

	public void setCdr(String cdr) {
		this.cdr = cdr;
	}

	public String getFile_name() {
		return file_name;
	}

	public void setFile_name(String file_name) {
		this.file_name = file_name;
	}

	public String getCreate_date() {
		return create_date;
	}

	public void setCreate_date(String create_date) {
		this.create_date = create_date;
	}

	@Override
	public String toString() {
		return "Fdm_rejected_Dumper [cdr=" + cdr + ", file_name=" + file_name + ", create_date=" + create_date + "]";
	}

}

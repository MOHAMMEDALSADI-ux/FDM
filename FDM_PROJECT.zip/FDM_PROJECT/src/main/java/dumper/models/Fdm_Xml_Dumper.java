package dumper.models;

public class Fdm_Xml_Dumper {

	String Cdr_Id;
	String Name, Last_Name, B_Date, National_Id, Phone, Gender, Address;

	String filename, create_date;

	public Fdm_Xml_Dumper(String cdr_Id, String name, String last_Name, String b_Date, String national_Id, String phone,
			String gender, String address, String filename, String create_date) {
		super();
		Cdr_Id = cdr_Id;
		Name = name;
		Last_Name = last_Name;
		B_Date = b_Date;
		National_Id = national_Id;
		Phone = phone;
		Gender = gender;
		Address = address;
		this.filename = filename;
		this.create_date = create_date;
	}

	public Fdm_Xml_Dumper() {
		super();
	}

	public String getCdr_Id() {
		return Cdr_Id;
	}

	public void setCdr_Id(String cdr_Id) {
		Cdr_Id = cdr_Id;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public String getLast_Name() {
		return Last_Name;
	}

	public void setLast_Name(String last_Name) {
		Last_Name = last_Name;
	}

	public String getB_Date() {
		return B_Date;
	}

	public void setB_Date(String b_Date) {
		B_Date = b_Date;
	}

	public String getNational_Id() {
		return National_Id;
	}

	public void setNational_Id(String national_Id) {
		National_Id = national_Id;
	}

	public String getPhone() {
		return Phone;
	}

	public void setPhone(String phone) {
		Phone = phone;
	}

	public String getGender() {
		return Gender;
	}

	public void setGender(String gender) {
		Gender = gender;
	}

	public String getAddress() {
		return Address;
	}

	public void setAddress(String address) {
		Address = address;
	}

	public String getFilename() {
		return filename;
	}

	public void setFilename(String filename) {
		this.filename = filename;
	}

	public String getCreate_date() {
		return create_date;
	}

	public void setCreate_date(String create_date) {
		this.create_date = create_date;
	}

	@Override
	public String toString() {
		return "Fdm_Xml_Dumper [Cdr_Id=" + Cdr_Id + ", Name=" + Name + ", Last_Name=" + Last_Name + ", B_Date=" + B_Date
				+ ", National_Id=" + National_Id + ", Phone=" + Phone + ", Gender=" + Gender + ", Address=" + Address
				+ ", filename=" + filename + ", create_date=" + create_date + "]";
	}

}

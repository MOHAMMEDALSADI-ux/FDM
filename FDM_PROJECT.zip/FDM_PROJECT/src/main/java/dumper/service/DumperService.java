package dumper.service;

import dumper.DAO.MoveFilesOut;

public class DumperService {

	public void startDumper() {

		MoveFilesOut moveFilesOut = new MoveFilesOut();
		moveFilesOut.fileToDumper();
	}
}

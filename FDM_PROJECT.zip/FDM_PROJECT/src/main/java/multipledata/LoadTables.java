package multipledata;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import main.Main;
import parser.models.FDM_TEMPLATE_FILE;
import parser.models.FDM_TYPES;

public class LoadTables {

	public final static String url = Main.properties.getProperty("url");

	public final static String IP = Main.properties.getProperty("DatabaseIP");

	public final static String ServerPost = Main.properties.getProperty("DatabasePost");

	public final static String Database_name = Main.properties.getProperty("DatabaseName");

	public final static String pass = Main.properties.getProperty("DatabasePass");

	public final static String username = Main.properties.getProperty("DatabaseUser");

	public final static String driver = Main.properties.getProperty("driver");

	public static String finalUrl;

	public static List<FDM_TEMPLATE_FILE> Template_List = new ArrayList<FDM_TEMPLATE_FILE>();

	public static List<FDM_TYPES> Types_List = new ArrayList<FDM_TYPES>();

	static PreparedStatement preparedStatement;
	static Connection connection;
	static ResultSet resultSet;

	static public void loadTable() {

		try {
			Class.forName(driver);

			finalUrl = url + IP + ServerPost + Database_name;

			// Pass the URL , username , password to getConnection() Method
			connection = DriverManager.getConnection(finalUrl, username, pass);
			String seletcTemplateTable = "Select * from fdm_template_file";
			preparedStatement = connection.prepareStatement(seletcTemplateTable);

			resultSet = preparedStatement.executeQuery();

			// Template Table
			while (resultSet.next()) {
				// Object Model
				FDM_TEMPLATE_FILE fdm_TEMPLATE_FILE = new FDM_TEMPLATE_FILE();
				int id = resultSet.getInt("ID");
				int type_id = resultSet.getInt("TYPE_ID");
				String tag_name = resultSet.getString("TAG_NAME");
				int order = resultSet.getInt("ORDER");
				boolean is_conditinal_tag = resultSet.getBoolean("IS_CONDITIONAL_TAG");

				fdm_TEMPLATE_FILE.setId(id);
				fdm_TEMPLATE_FILE.setType_id(type_id);
				fdm_TEMPLATE_FILE.setTag_name(tag_name);
				fdm_TEMPLATE_FILE.setOrder(order);
				fdm_TEMPLATE_FILE.setIs_conditional_tag(is_conditinal_tag);

				Template_List.add(fdm_TEMPLATE_FILE);
			}
			// Types Table

			String seletcTypesTable = "Select * from fdm_types";
			preparedStatement = connection.prepareStatement(seletcTypesTable);
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				FDM_TYPES fdm_TYPES = new FDM_TYPES();

				int id = resultSet.getInt("ID");
				String types = resultSet.getString("TYPES");

				fdm_TYPES.setId(id);
				fdm_TYPES.setTypes(types);

				Types_List.add(fdm_TYPES);
			}

			resultSet.close();
			preparedStatement.close();
			connection.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}

package multipledata;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class GetTypeOfFile {

	// TODO Get Type of file if its json or xml from Parser Table
	public String typeIdForFile(String tracingId) {

		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		String typeId = "";
		try {

			if (!tracingId.isEmpty()) {
				connection = GetSpecificData.getConnection();

				String getTypeId = "SELECT * FROM dumper_manager.fdm_parser_status WHERE TRACING_ID = \"" + tracingId
						+ "\"";

				preparedStatement = connection.prepareStatement(getTypeId);

				resultSet = preparedStatement.executeQuery();

				while (resultSet.next()) {
					typeId = resultSet.getString("TYPE_ID");
				}
			}
			resultSet.close();
			preparedStatement.close();
			connection.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return typeId;
	}
}

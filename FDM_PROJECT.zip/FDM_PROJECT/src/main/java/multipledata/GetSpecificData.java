package multipledata;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

import org.apache.commons.io.comparator.LastModifiedFileComparator;

public class GetSpecificData {

	public static List<String> listFiles = new ArrayList<String>();

	// TODO Method For Open DataBase Connection
	static public Connection getConnection() {

		String driver = LoadTables.driver;
		String pass = LoadTables.pass;
		String username = LoadTables.username;
		String finalUrl = LoadTables.finalUrl;

		Connection connection = null;
		try {
			// Load the JDBC driver
			Class.forName(driver);
			// Pass the URL , username , password to getConnection() Method
			connection = DriverManager.getConnection(finalUrl, username, pass);

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return connection;
	}

	// TODO Method For Get Date and time (Create_Date)
	static public String datetime() {

		// Create Date and Time For DataBase Record
		DateTimeFormatter date = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
		LocalDateTime time = LocalDateTime.now();
		String dateTime = date.format(time);

		return dateTime;
	}

	// TODO Method For Count number of CRD of the file
	static public long numberOfCDR(String filePath) {

		long numberOfCdr = 0;

		try {
			Path path = Paths.get(filePath);
			numberOfCdr = Files.lines(path).count();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return numberOfCdr;

	}

	// TODO Method For Create unique random number (Tracing ID)
	static public String createTracingId() {
		Random random = new Random();
		String randomId = random.nextInt(11111, 99999) + "";

		return randomId;
	}

	// TODO Method For get the tracingId from the file name
	static public String getTracingId(String fileName) {

		String TracingId = fileName.substring(fileName.lastIndexOf('-') + 1, fileName.lastIndexOf('.'));

		return TracingId;
	}

	// TODO Method For Get File From Source Directory (Last Modified)
	static public List<String> getListOfFileLastModified(String SourcePath) {

		File file = new File(SourcePath);
		List<String> listFiles = new ArrayList<String>();
		File[] listOfFile = file.listFiles();
		Arrays.sort(listOfFile, LastModifiedFileComparator.LASTMODIFIED_COMPARATOR);

		for (int i = 0; i < listOfFile.length; i++) {
			listFiles.add(listOfFile[i].toString());
		}
		
		return listFiles;
	}

	// TODO Method For Get all Files From Specific Directory
	static public List<String> getListOfFiles(String FolderPath) {

		File file = new File(FolderPath);
		List<String> listFiles = new ArrayList<String>();

		File[] listOfFile = file.listFiles();

		for (int i = 0; i < listOfFile.length; i++) {
			listFiles.add(listOfFile[i].toString());
		}
		return listFiles;

	}

	// TODO Method For Get FileName From FilePath
	static public String getFileName(String filepath) {

		String fileName = filepath.substring(filepath.lastIndexOf('\\') + 1, filepath.length());

		return fileName;

	}

	// TODO Method For Get SourceFileName From FileName
	static public String getSourceFileName(String fileName) {

		String sourceFileName = fileName.substring(0, fileName.indexOf('-'));

		return sourceFileName;
	}

	// TODO Method For Get TypeId Of File
	static public String getTypeId(String fileName) {

		String typeId = fileName.substring(fileName.indexOf('-') + 1, fileName.indexOf('-') + 2);

		return typeId;
	}

}
